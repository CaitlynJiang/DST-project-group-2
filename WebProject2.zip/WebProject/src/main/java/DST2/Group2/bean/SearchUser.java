package DST2.Group2.bean;

import DST2.Group2.bean.User;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SearchUser {

    public static boolean searchUser(User user) {
        Connection c = null;
        Statement stmt = null;
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection("jdbc:postgresql://localhost:5432/DSTlogin","postgres","yourpassword");
            System.out.println("connected to postgresql");
            stmt = c.createStatement();
            String sql = "select passwords from Users \n" +
                    "where username = \'"+user.username+"\';";
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
                String password = rs.getString("passwords");
                System.out.println(password);
                System.out.println(password.equals(user.password));
                if (password!="" && password.equals(user.password)) {
                    System.out.println(password);
                } else {
                    System.out.println("false");
                    rs.close();
                    stmt.close();
                    c.close();
                    return false;
                }
            }
            rs.close();
            stmt.close();
            c.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }
        System.out.println("searched");
        return true;
    }
}
