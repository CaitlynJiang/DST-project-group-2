package DST2.Group2.bean;

public class User {

    public String username;
    public String password;

    public User(String UN, String PW) {
        this.username = UN;
        this.password = PW;
    }



}
